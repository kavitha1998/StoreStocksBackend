package com.FoodDonation.FoodDonation.InsertData;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.http.HttpStatus;

import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
public class FDInsertTescoFDSV2Pilot {

    @Autowired
    @Qualifier("TescoFDSv2_PilotJdbcTemplate")
    private JdbcTemplate TescoFDSv2_PilotJdbcTemplate;

    @PostMapping("/insertFDSV2Pilot")
    public ResponseEntity<Object> addStoreCountry(@RequestBody Map<String, String> requestParams) {
        String Id = UUID.randomUUID().toString();
        String Retailer = requestParams.get("Retailer");
        String Name = requestParams.get("Name");
        String Code = requestParams.get("Code");
        String Live = requestParams.get("Live");
        String Address = requestParams.get("Address");
        String Postcode = requestParams.get("Postcode");
        Float GPSLat = Float.parseFloat(requestParams.get("GPSLat"));
        Float GPSLong = Float.parseFloat(requestParams.get("GPSLong"));
        String IPAddress = requestParams.get("IPAddress");
        String Options = requestParams.get("Options");
        String NextSchedule = requestParams.get("NextSchedule");
        String OpeningHours = requestParams.get("OpeningHours");
        String Comments = requestParams.get("Comments");
        String Updated = requestParams.get("Updated");
        String URL = requestParams.get("URL");
        String LocationUUID = requestParams.get("LocationUUID");
        String CountryCode = requestParams.get("CountryCode");
        String StoreFormat = requestParams.get("StoreFormat");

        try {
            // Check if code exists in Store table
            int storeCount = TescoFDSv2_PilotJdbcTemplate.queryForObject(
                    "SELECT COUNT(*) FROM Store WHERE Code = ?", Integer.class, Code);

            if (storeCount > 0) {
                return ResponseEntity.status(HttpStatus.CONFLICT)
                        .body("Error: Store with code " + Code + " already exists.");
            }

            // Insert into Store table
            TescoFDSv2_PilotJdbcTemplate.update(
                    "INSERT INTO Store(Id, Retailer, Name, Code, Live, Address, Postcode, GPSLat, GPSLong, IPAddress, NextSchedule, Options, OpeningHours, Comments, Updated, URL, LocationUUID, CountryCode, StoreFormat) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    Id, Retailer, Name, Code, Live, Address, Postcode, GPSLat, GPSLong, IPAddress, NextSchedule, Options, OpeningHours, Comments, Updated, URL, LocationUUID, CountryCode, StoreFormat);

            // Insert into StoreCategory table
            TescoFDSv2_PilotJdbcTemplate.update(
                    "INSERT INTO StoreCategory(Store, Category) SELECT a.Id, b.Id FROM Store a, Category b WHERE a.Code = ?",
                    Code);

            return ResponseEntity.ok()
                    .body("Success: Data inserted successfully into Store and StoreCategory.");
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error: Failed to insert data. " + e.getMessage());
        }
    }

    @GetMapping("/getAllStores")
    public ResponseEntity<List<Map<String, Object>>> getAllStores(@RequestParam String code) {
        try {
            List<Map<String, Object>> stores = TescoFDSv2_PilotJdbcTemplate.queryForList("SELECT * FROM Store WHERE Code=?", code);
            return ResponseEntity.ok().body(stores);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }
}
