package com.Counts.Counts.Config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.boot.jdbc.DataSourceBuilder;

import javax.sql.DataSource;

@Configuration
public class CountsConfig {

    @Bean(name = "sqlServerDataSource")
    public DataSource sqlServerDataSource() {
        return DataSourceBuilder.create()
                .url("jdbc:sqlserver://127.0.0.1:1433;databaseName=Tesco_CAA;encrypt=false")
                .username("sa")
                .password("Soprasteria@12345")
                .driverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver")
                .build();
    }

    @Bean(name = "sqlServerJdbcTemplate")
    public JdbcTemplate sqlServerJdbcTemplate(DataSource sqlServerDataSource) {
        return new JdbcTemplate(sqlServerDataSource);
    }
}
