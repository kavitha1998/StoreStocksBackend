package com.Counts.Counts.InsertData;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.http.HttpStatus;

import java.util.HashMap;
import java.util.Map;

@RestController
public class CountsInsert {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    @Qualifier("sqlServerJdbcTemplate")
    private JdbcTemplate sqlServerJdbcTemplate;

    @PostMapping("/countsinsert")
    public ResponseEntity<String> addStoreCounts(@RequestBody Map<String, String> requestParams) {
       // String storeId = requestParams.get("StoreID");
        String storeNumber = requestParams.get("StoreNumber");
        String ipPrefix = requestParams.get("IpPrefix");
        String associatedStoreNumber = requestParams.get("AssociatedStoreNumber");
        String countryCode = requestParams.get("CountryCode");
        String activationStatusId = requestParams.get("ActivationStatusId");
        String activationId = requestParams.get("ActivationId");
        String storeName = requestParams.get("StoreName");
        String formatId = requestParams.get("FormatId");
        String groupId = requestParams.get("GroupId");
        String activeFlag = requestParams.get("ActiveFlag");
        String countryId = requestParams.get("CountryId");
        String machineId = requestParams.get("MachineId");
        String pfsEnabled = requestParams.get("PFSEnabled");
        String stream = requestParams.get("Stream");
        String codelevel = requestParams.get("Codelevel");
        String crDNSEnvironment = requestParams.get("CrDNSEnvironment");
        String partNumber = requestParams.get("PartNumber");
        String currency = requestParams.get("Currency");
        String message = "";

        try {
            int storeCount = jdbcTemplate.queryForObject(
                    "SELECT COUNT(*) FROM Store WHERE StoreNumber = ?", Integer.class, storeNumber);
            int tblstoreCount = jdbcTemplate.queryForObject(
                    "SELECT COUNT(*) FROM tblstore WHERE StoreID = ?", Integer.class, storeNumber);
            int tstoreCount = jdbcTemplate.queryForObject(
                    "SELECT COUNT(*) FROM tStore WHERE StoreNumber = ?", Integer.class, storeNumber);

            if (storeCount == 0 && tblstoreCount == 0 && tstoreCount == 0) {
                // Condition 1: T1=N,T2=N,T3=N insert data into T1,T2,T3
                // Insert into Store
                jdbcTemplate.update(
                        "INSERT INTO Store(StoreNumber, IpPrefix, AssociatedStoreNumber, CountryCode, ActivationStatusId) VALUES (?, ?, ?, ?, ?)",
                        storeNumber, ipPrefix, associatedStoreNumber, countryCode, activationStatusId);
                // Insert into tblstore
                jdbcTemplate.update(
                        "INSERT INTO tblstore(StoreID, IpPrefix, ActivationId) VALUES (?, ?, ?)",
                        storeNumber, ipPrefix, activationId);
                // Insert into tStore
                jdbcTemplate.update(
                        "INSERT INTO tStore(StoreNumber, StoreName, FormatId, GroupId, IpPrefix, ActiveFlag, CountryId, MachineId, PFSEnabled, Stream, Codelevel, CrDNSEnvironment, PartNumber, CountryCode, Currency) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                        storeNumber, storeName, formatId, groupId, ipPrefix, activeFlag, countryId, machineId, pfsEnabled, stream, codelevel, crDNSEnvironment, partNumber, countryCode, currency);

                message = "Data inserted successfully into Store, tblstore, and tStore.";
            } else if (storeCount == 0 && tblstoreCount == 1 && tstoreCount == 1) {
                // Condition 2: T1=N,T2=Y,T3=Y insert data into T1
                // Insert into Store
                jdbcTemplate.update(
                        "INSERT INTO Store(StoreNumber, IpPrefix, AssociatedStoreNumber, CountryCode, ActivationStatusId) VALUES (?, ?, ?, ?, ?)",
                        storeNumber, ipPrefix, associatedStoreNumber, countryCode, activationStatusId);
                message = "Data inserted successfully into Store.";
            } else if (storeCount == 1 && tblstoreCount == 0 && tstoreCount == 1) {
                // Condition 3: T1=Y,T2=N,T3=Y insert data into T2
                // Insert into tblstore
                jdbcTemplate.update(
                        "INSERT INTO tblstore(StoreID, IpPrefix, ActivationId) VALUES (?, ?, ?)",
                        storeNumber, ipPrefix, activationId);
                message = "Data inserted successfully into tblstore.";
            } else if (storeCount == 1 && tblstoreCount == 1 && tstoreCount == 0) {
                // Condition 4: T1=Y,T2=Y,T3=N insert data into T3
                // Insert into tStore
                jdbcTemplate.update(
                        "INSERT INTO tStore(StoreNumber, StoreName, FormatId, GroupId, IpPrefix, ActiveFlag, CountryId, MachineId, PFSEnabled, Stream, Codelevel, CrDNSEnvironment, PartNumber, CountryCode, Currency) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                        storeNumber, storeName, formatId, groupId, ipPrefix, activeFlag, countryId, machineId, pfsEnabled, stream, codelevel, crDNSEnvironment, partNumber, countryCode, currency);
                message = "Data inserted successfully into tStore.";
            } else if (storeCount == 0 && tblstoreCount == 0 && tstoreCount == 1) {
                // Condition 5: T1=N,T2=N,T3=Y insert data into T1 and T2
                // Insert into Store
                jdbcTemplate.update(
                        "INSERT INTO Store(StoreNumber, IpPrefix, AssociatedStoreNumber, CountryCode, ActivationStatusId) VALUES (?, ?, ?, ?, ?)",
                        storeNumber, ipPrefix, associatedStoreNumber, countryCode, activationStatusId);
                // Insert into tblstore
                jdbcTemplate.update(
                        "INSERT INTO tblstore(StoreID, IpPrefix, ActivationId) VALUES (?, ?, ?)",
                        storeNumber, ipPrefix, activationId);
                message = "Data inserted successfully into Store and tblstore.";
            } else if (storeCount == 1 && tblstoreCount == 0 && tstoreCount == 0) {
                // Condition 6: T1=Y,T2=N,T3=N insert data into T2 and T3
                // Insert into tblstore
                jdbcTemplate.update(
                        "INSERT INTO tblstore(StoreID, IpPrefix, ActivationId) VALUES (?, ?, ?)",
                        storeNumber, ipPrefix, activationId);
                // Insert into tStore
                jdbcTemplate.update(
                        "INSERT INTO tStore(StoreNumber, StoreName, FormatId, GroupId, IpPrefix, ActiveFlag, CountryId, MachineId, PFSEnabled, Stream, Codelevel, CrDNSEnvironment, PartNumber, CountryCode, Currency) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                        storeNumber, storeName, formatId, groupId, ipPrefix, activeFlag, countryId, machineId, pfsEnabled, stream, codelevel, crDNSEnvironment, partNumber, countryCode, currency);
                message = "Data inserted successfully into tblstore and tStore.";
            } else if (storeCount == 0 && tblstoreCount == 1 && tstoreCount == 0) {
                // Condition 7: T1=N,T2=Y,T3=N insert data into T1 and T3
                // Insert into Store
                jdbcTemplate.update(
                        "INSERT INTO Store(StoreNumber, IpPrefix, AssociatedStoreNumber, CountryCode, ActivationStatusId) VALUES (?, ?, ?, ?, ?)",
                        storeNumber, ipPrefix, associatedStoreNumber, countryCode, activationStatusId);

                // Insert into tStore
                jdbcTemplate.update(
                        "INSERT INTO tStore(StoreNumber, StoreName, FormatId, GroupId, IpPrefix, ActiveFlag, CountryId, MachineId, PFSEnabled, Stream, Codelevel, CrDNSEnvironment, PartNumber, CountryCode, Currency) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                        storeNumber, storeName, formatId, groupId, ipPrefix, activeFlag, countryId, machineId, pfsEnabled, stream, codelevel, crDNSEnvironment, partNumber, countryCode, currency);
                message = "Data inserted successfully into Store and tStore.";
            } else {
                // Condition 8: T1=Y,T2=Y,T3=Y data already exist in the table
                message = "Data already exists in the tables.";
            }

            return ResponseEntity.ok().body(message);
        } catch (Exception e) {
            message = "Error: " + e.getMessage();
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(message);
        }
    }

   /* @GetMapping("/retrieveCountsData")
    public ResponseEntity<Map<String, Object>> retrieveCountsData(String storeNumber) {
        try {
            Map<String, Object> data = jdbcTemplate.queryForMap("SELECT * FROM tStore WHERE StoreNumber = ?",storeNumber );
            return ResponseEntity.ok().body(data);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }*/

    @GetMapping("/retrieveCountsData")
    public ResponseEntity<Map<String, Object>> retrieveCountsData(String storeNumber) {
        try {
            // Query to retrieve data from tStore
            Map<String, Object> data = jdbcTemplate.queryForMap("SELECT * FROM tStore WHERE StoreNumber = ?", storeNumber);

            // Query to retrieve ActivationId from tblstore
            String activationId = jdbcTemplate.queryForObject("SELECT ActivationId FROM tblstore WHERE StoreId = ?", String.class, storeNumber);
            data.put("ActivationId", activationId); // Add ActivationId to the data map

            // Query to retrieve AssociatedStoreNumber and activationStatusId from Store
            Map<String, Object> storeData = jdbcTemplate.queryForMap("SELECT AssociatedStoreNumber, ActivationStatusId FROM Store WHERE StoreNumber = ?", storeNumber);
            data.putAll(storeData); // Add AssociatedStoreNumber and activationStatusId to the data map

            return ResponseEntity.ok().body(data);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

}
