package com.RFS.RFS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RfsApplication {

	public static void main(String[] args) {
		SpringApplication.run(RfsApplication.class, args);
	}

}
