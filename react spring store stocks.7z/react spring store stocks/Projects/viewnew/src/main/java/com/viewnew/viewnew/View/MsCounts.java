package com.viewnew.viewnew.View;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.http.HttpStatus;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class MsCounts {

    @Autowired
    private JdbcTemplate CountsJdbcTemplate;

    @GetMapping("/viewdbdatamsCounts")
    public ResponseEntity<Map<String, List<Map<String, Object>>>> getStoreDetails(@RequestParam("StoreID") int storeID) {
        try {
            Map<String, List<Map<String, Object>>> responseData = new HashMap<>();

            String query3 = "SELECT * FROM Store WHERE Storeid = ?";
            List<Map<String, Object>> storeDetails3 = CountsJdbcTemplate.queryForList(query3, storeID);
            responseData.put("counts Store", storeDetails3);

            String query4 = "SELECT * FROM tblstore WHERE Storeid = ?";
            List<Map<String, Object>> storeDetails4 = CountsJdbcTemplate.queryForList(query4, storeID);
            responseData.put("Counts tblstore", storeDetails4);

            String query5 = "SELECT * FROM tStore WHERE StoreNumber = ?";
            List<Map<String, Object>> storeDetails5 = CountsJdbcTemplate.queryForList(query5, storeID);
            responseData.put("Counts tStore", storeDetails5);

            return ResponseEntity.ok().body(responseData);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }
}
