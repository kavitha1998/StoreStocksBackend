package com.RFS.RFS.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.boot.jdbc.DataSourceBuilder;

import javax.sql.DataSource;

@Configuration
public class RFSConfig {

    @Bean(name = "RFSDataSource")
    public DataSource RFSDataSource() {
        return DataSourceBuilder.create()
                .url("jdbc:sqlserver://127.0.0.1:1433;databaseName=RFS_Prod;encrypt=false")
                .username("sa")
                .password("Soprasteria@12345")
                .driverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver")
                .build();
    }

    @Bean(name = "RFSJdbcTemplate")
    public JdbcTemplate RFSdbcTemplate(DataSource RFSDataSource) {
        return new JdbcTemplate(RFSDataSource);
    }
}
