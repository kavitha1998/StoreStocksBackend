package com.FoodDonation.FoodDonation.Config;

import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.boot.jdbc.DataSourceBuilder;



@Configuration
public class FoodDonationConfig {

    @Bean(name = "TescoFDSDataSource")
    public DataSource TescoFDSDataSource() {
        return DataSourceBuilder
                .create()
                .url("jdbc:sqlserver://127.0.0.1:1433;databaseName=TescoFDS;encrypt=false")
                .username("sa")
                .password("Soprasteria@12345")
                .driverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver")
                .build();
    }

    @Bean(name = "TescoFDSv2DataSource")
    public DataSource TescoFDSv2DataSource() {
        return DataSourceBuilder
                .create()
                .url("jdbc:sqlserver://127.0.0.1:1433;databaseName=TescoFDSv2;encrypt=false")
                .username("sa")
                .password("Soprasteria@12345")
                .driverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver")
                .build();
    }

   @Bean(name = "TescoFDSv2_PilotDataSource")
    public DataSource TescoFDSv2_PilotDataSource() {
        return DataSourceBuilder
                .create()
                .url("jdbc:sqlserver://127.0.0.1:1433;databaseName=TescoFDSv2_Pilot;encrypt=false")
                .username("sa")
                .password("Soprasteria@12345")
                .driverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver")
                .build();
    }


    @Bean(name = "TescoFDSJdbcTemplate")
    public JdbcTemplate TescoFDSJdbcTemplate(@Qualifier("TescoFDSDataSource") DataSource tescoDataSource) {
        return new JdbcTemplate(tescoDataSource);
    }
    @Bean(name = "TescoFDSv2JdbcTemplate")
    public JdbcTemplate TescoFDSv2JdbcTemplate(@Qualifier("TescoFDSv2DataSource") DataSource tescoDataSource) {
        return new JdbcTemplate(tescoDataSource);
    }


    @Bean(name = "TescoFDSv2_PilotJdbcTemplate")
    public JdbcTemplate TescoFDSv2_PilotJdbcTemplate(@Qualifier("TescoFDSv2_PilotDataSource") DataSource directDeliveriesDataSource) {
        return new JdbcTemplate(directDeliveriesDataSource);
    }
}
