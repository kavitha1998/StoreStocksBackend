package com.FoodDonation.FoodDonation.InsertData;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.http.HttpStatus;

import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
public class FDInsertTescoFDSV2 {

    @Autowired
    @Qualifier("TescoFDSv2JdbcTemplate")
    private JdbcTemplate TescoFDSv2JdbcTemplate;

    @PostMapping("/insertFDSV2")
    public ResponseEntity<String> addStoreCountry(@RequestBody Map<String, String> requestParams) {
        String Id = requestParams.get("Id");
        String Retailer = requestParams.get("Retailer");
        String Name = requestParams.get("Name");
        String Code = requestParams.get("Code");
        String Live = requestParams.get("Live");
        String Address = requestParams.get("Address");
        String Postcode = requestParams.get("Postcode");
        Float GPSLat = Float.parseFloat(requestParams.get("GPSLat"));
        Float GPSLong = Float.parseFloat(requestParams.get("GPSLong"));
        String IPAddress = requestParams.get("IPAddress");
        String Options = requestParams.get("Options");
        String NextSchedule = requestParams.get("NextSchedule");
        String OpeningHours = requestParams.get("OpeningHours");
        String Comments = requestParams.get("Comments");
        String Updated = requestParams.get("Updated");
        String URL = requestParams.get("URL");
        String message = "";

        try {
            // Check if code exists in Store table
            int storeCount = TescoFDSv2JdbcTemplate.queryForObject(
                    "SELECT COUNT(*) FROM Store WHERE Code = ?", Integer.class, Code);

            if (storeCount > 0) {
                message = "Error: Store with code " + Code + " already exists.";
                return ResponseEntity.status(HttpStatus.CONFLICT).body(message);
            }

            // Insert into Store table if code does not exist
            TescoFDSv2JdbcTemplate.update(
                    "INSERT INTO Store(Id, Retailer, Name, Code, Live, Address, Postcode, GPSLat, GPSLong, IPAddress, NextSchedule, Options, OpeningHours, Comments, Updated, URL) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    Id, Retailer, Name, Code, Live, Address, Postcode, GPSLat, GPSLong, IPAddress, NextSchedule, Options, OpeningHours, Comments, Updated, URL);
            message = "Data inserted successfully into Store";

            // Insert into StoreCategory table
            TescoFDSv2JdbcTemplate.update(
                    "INSERT INTO StoreCategory(Store, Category) SELECT a.Id, b.Id FROM Store a, Category b WHERE a.Code = ?",
                    Code);

            message += " and StoreCategory.";
            return ResponseEntity.ok().body(message);
        } catch (Exception e) {
            message = "Error: " + e.getMessage();
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(message);
        }
    }

    @GetMapping("/getTescoFDSV2")
    public ResponseEntity<List<Map<String, Object>>> getAllStores(@RequestParam String code) {
        try {
            List<Map<String, Object>> stores = TescoFDSv2JdbcTemplate.queryForList("SELECT * FROM Store WHERE Code=?", code);
            return ResponseEntity.ok().body(stores);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }
}
