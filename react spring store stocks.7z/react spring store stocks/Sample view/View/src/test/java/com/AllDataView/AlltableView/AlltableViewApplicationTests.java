package com.AllDataView.AlltableView;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlltableViewApplicationTests {

	@Test
	void contextLoads() {
	}

}
