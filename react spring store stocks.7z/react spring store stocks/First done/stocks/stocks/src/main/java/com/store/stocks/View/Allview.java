/*package com.store.stocks.View;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.http.HttpStatus;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class Allview {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @GetMapping("/viewdbdata")
    public ResponseEntity<Map<String, List<Map<String, Object>>>> getStoreDetails(@RequestParam("StoreID") int storeID) {
        try {
            Map<String, List<Map<String, Object>>> responseData = new HashMap<>();

            String query1 = "SELECT * FROM store.tbl_store_country WHERE StoreID = ?";
            List<Map<String, Object>> storeDetails1 = jdbcTemplate.queryForList(query1, storeID);
            responseData.put("DD tbl_store_country", storeDetails1);

            String query2 = "SELECT * FROM store.tbl_store WHERE StoreID = ?";
            List<Map<String, Object>> storeDetails2 = jdbcTemplate.queryForList(query2, storeID);
            responseData.put("DD tbl_store", storeDetails2);

            String query3 = "SELECT * FROM rfs_prod.tbl_store WHERE STORE_NUMBER = ?";
            List<Map<String, Object>> storeDetails3 = jdbcTemplate.queryForList(query3, storeID);
            responseData.put("RFS tbl_store", storeDetails3);

            String query4 = "SELECT * FROM rfs_prod.tbl_store_tnt WHERE STORE_NUMBER = ?";
            List<Map<String, Object>> storeDetails4 = jdbcTemplate.queryForList(query4, storeID);
            responseData.put("RFS tbl_store_tnt", storeDetails4);
            /*String query5 = "SELECT * FROM db_DirectDeliveries.tbl_Store WHERE StoreID = ?";
            List<Map<String, Object>> storeDetails5 = jdbcTemplate.queryForList(query5, storeID);
            responseData.put("MS tbl_store", storeDetails5);*/
/*
            return ResponseEntity.ok().body(responseData);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }
}*/
