
package com.RFS.RFS.InsertData;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.http.HttpStatus;

import java.util.Map;

@RestController
public class RFSInsert {


    @Autowired
    @Qualifier("RFSJdbcTemplate")
    private JdbcTemplate RFSJdbcTemplate;

    @PostMapping("/RFSinsert")
    public ResponseEntity<String> addStoreCountry(@RequestBody Map<String, String> requestParams) {



        String storenumber = requestParams.get("storenumber");
        String storename = requestParams.get("storename");
        String postcode = requestParams.get("postcode");
        String countrydisplay = requestParams.get("countrydisplay");
        String storedisplaytype = requestParams.get("storedisplaytype");
        String tntpostcode = requestParams.get("tntpostcode");
        String tntdepot = requestParams.get("tntdepot");
        String createdby = requestParams.get("createdby");
        String streetaddress1 = requestParams.get("streetaddress1");
        String streetaddress2 = requestParams.get("streetaddress2");
        String streetaddress3 = requestParams.get("streetaddress3");
        String city = requestParams.get("city");
        String province = requestParams.get("province");
        String countrycode = requestParams.get("countrycode");
        String vat = requestParams.get("vat");
        String contactname = requestParams.get("contactname");
        String contactdailcode = requestParams.get("contactdailcode");
        String contacttelephone = requestParams.get("contacttelephone");
        String contactemail = requestParams.get("contactemail");
        String prefcollectiontimefrom = requestParams.get("prefcollectiontimefrom");
        String prefcollectiontimeto = requestParams.get("prefcollectiontimeto");
        String collectioninstruction = requestParams.get("collectioninstruction");
        String createddatetime = requestParams.get("createddatetime");
        String tntflag = requestParams.get("tntflag");
        String formatid = requestParams.get("formatid");
        String countryid = requestParams.get("countryid");
        String groupid = requestParams.get("groupid");
        String machineid= requestParams.get("machineid");
        String tescoglnnumber = requestParams.get("tescoglnnumber");
        String ipprefix= requestParams.get("ipprefix");
        String ispilotstore= requestParams.get("ispilotstore");
        String activeflag= requestParams.get("activeflag");
        String storeuuid= requestParams.get("storeuuid");
        String message = "";

        try {
            int store= RFSJdbcTemplate.queryForObject(
                    "SELECT COUNT(*) FROM TBL_STORE WHERE STORE_NUMBER = ?", Integer.class, storenumber);
            int storetnt = RFSJdbcTemplate.queryForObject(
                    "SELECT COUNT(*) FROM TBL_STORE_TNT WHERE STORE_NUMBER = ?", Integer.class, storenumber);

            if (store > 0) {
                if (storetnt == 0) {
                    message = "StoreID already exists in tbl_Store. Data inserted successfully in tbl_Store_tnt.";
                    RFSJdbcTemplate.update(
                            "INSERT INTO TBL_STORE_TNT (STORE_NUMBER, STORE_NAME, POST_CODE, COUNTRY_DISPLAY, STORE_DISPLAY_TYPE, TNT_POST_CODE, TNT_DEPOT, CREATED_BY, STREETADDRESS1, STREETADDRESS2, STREETADDRESS3, CITY, PROVINCE, COUNTRY_CODE, VAT, CONTACTNAME, CONTACTDAILCODE, CONTACTTELEPHONE, CONTACTEMAIL, PREFCOLLECTIONTIME_FROM, PREFCOLLECTIONTIME_TO, COLLECTION_INSTRUCTION) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",storenumber,storename,postcode
                            ,countrydisplay,storedisplaytype,tntpostcode,tntdepot,createdby,streetaddress1,streetaddress2,streetaddress3,city,province,countrycode,vat,contactname,contactdailcode,
                            contacttelephone,contactemail,prefcollectiontimefrom,prefcollectiontimeto,collectioninstruction);
                } else {
                    message = "StoreID already exists in tbl_Store and tbl_Store_tnt.";
                }
            } else {
                if (storetnt > 0) {
                    message = "StoreID already exists in tbl_Store_tnt. Data inserted successfully in tbl_Store.";
                    RFSJdbcTemplate.update(

                            "INSERT INTO TBL_STORE (STORE_NUMBER, STORE_NAME, FORMAT_ID, COUNTRY_ID, GROUP_ID, MACHINE_ID, TESCO_GLN_NUMBER, IP_PREFIX, CREATED_BY, ACTIVE_FLAG, TNT_FLAG, IS_PILOT_STORE, STORE_UUID) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
                            ,storenumber,storename,formatid,countryid,groupid,machineid,tescoglnnumber,ipprefix,createdby,activeflag,tntflag,ispilotstore,storeuuid);

                } else {
                    message = "Data inserted successfully into tbl_Store and tbl_Store_tnt.";
                    RFSJdbcTemplate.update(

                            "INSERT INTO TBL_STORE (STORE_NUMBER, STORE_NAME, FORMAT_ID, COUNTRY_ID, GROUP_ID, MACHINE_ID, TESCO_GLN_NUMBER, IP_PREFIX, CREATED_BY, ACTIVE_FLAG, TNT_FLAG, IS_PILOT_STORE, STORE_UUID) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                            storenumber,storename,formatid,countryid,groupid,machineid,tescoglnnumber,ipprefix,createdby,activeflag,tntflag,ispilotstore,storeuuid);

                    RFSJdbcTemplate.update(
                            "INSERT INTO TBL_STORE_TNT (STORE_NUMBER, STORE_NAME, POST_CODE, COUNTRY_DISPLAY, STORE_DISPLAY_TYPE, TNT_POST_CODE, TNT_DEPOT, CREATED_BY, STREETADDRESS1, STREETADDRESS2, STREETADDRESS3, CITY, PROVINCE, COUNTRY_CODE, VAT, CONTACTNAME, CONTACTDAILCODE, CONTACTTELEPHONE, CONTACTEMAIL, PREFCOLLECTIONTIME_FROM, PREFCOLLECTIONTIME_TO, COLLECTION_INSTRUCTION) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                            storenumber,storename,postcode
                            ,countrydisplay,storedisplaytype,tntpostcode,tntdepot,createdby,streetaddress1,streetaddress2,streetaddress3,city,province,countrycode,vat,contactname,contactdailcode,
                            contacttelephone,contactemail,prefcollectiontimefrom,prefcollectiontimeto,collectioninstruction);
                }
            }
            return ResponseEntity.ok().body(message);
        } catch (Exception e) {
            message = "Error: " + e.getMessage();
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(message);
        }
    }
}


