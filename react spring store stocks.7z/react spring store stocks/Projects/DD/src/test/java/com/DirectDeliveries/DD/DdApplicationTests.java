package com.DirectDeliveries.DD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DdApplicationTests {

	@Test
	void contextLoads() {
	}

}
