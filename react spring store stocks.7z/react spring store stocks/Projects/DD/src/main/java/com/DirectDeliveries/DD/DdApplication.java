package com.DirectDeliveries.DD;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DdApplication {

	public static void main(String[] args) {
		SpringApplication.run(DdApplication.class, args);
	}

}
