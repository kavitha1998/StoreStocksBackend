package com.Counts.Counts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CountsApplication {

	public static void main(String[] args) {
		SpringApplication.run(CountsApplication.class, args);
	}

}
