package com.AllDataView.AlltableView.AllDataView;


import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.http.HttpStatus;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class AllView

{

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @GetMapping("/viewdbdatams")
    public ResponseEntity<Map<String, List<Map<String, Object>>>> getStoreDetails(@RequestParam("StoreID") int storeID) {
        try {
            Map<String, List<Map<String, Object>>> responseData = new HashMap<>();


            String query5 = "SELECT * FROM tbl_Store WHERE StoreID = ?";
            List<Map<String, Object>> storeDetails5 = jdbcTemplate.queryForList(query5, storeID);
            responseData.put("Direct Deliveries tbl_store", storeDetails5);

            String query2 = "SELECT * FROM tbl_Store_Country WHERE StoreID = ?";
            List<Map<String, Object>> storeDetails2= jdbcTemplate.queryForList(query2, storeID);
            responseData.put("Direct Deliveries tbl_store_Country", storeDetails2);

            return ResponseEntity.ok().body(responseData);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }
}


