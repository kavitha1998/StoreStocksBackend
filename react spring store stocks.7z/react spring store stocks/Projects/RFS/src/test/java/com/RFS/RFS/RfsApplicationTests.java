package com.RFS.RFS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RfsApplicationTests {

	@Test
	void contextLoads() {
	}

}
