package com.viewnew.viewnew.View;



import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.http.HttpStatus;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class RFS {

    @Autowired
    private JdbcTemplate RFSJdbcTemplate;

    @GetMapping("/RFSView")
    public ResponseEntity<Map<String, List<Map<String, Object>>>> RFSViewdetails(@RequestParam("StoreID") int storeID) {
        try {
            Map<String, List<Map<String, Object>>> responseData = new HashMap<>();

            String query1 = "SELECT * FROM TBL_STORE WHERE STORE_NUMBER = ?";
            List<Map<String, Object>> storeDetails1 = RFSJdbcTemplate.queryForList(query1, storeID);
            responseData.put("RFS tbl_store", storeDetails1);

            String query2 = "SELECT * FROM TBL_STORE_TNT WHERE STORE_NUMBER = ?";
            List<Map<String, Object>> storeDetails2 = RFSJdbcTemplate.queryForList(query2, storeID);
            responseData.put("RFS tbl_store_tnt", storeDetails2);

            return ResponseEntity.ok().body(responseData);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }
}