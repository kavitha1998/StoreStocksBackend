package com.viewnew.viewnew.View;




import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.http.HttpStatus;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class FooddonationFDSV2 {

    @Autowired
    private JdbcTemplate TescoFDSJdbcTemplate;

    @GetMapping("/FoodDonationFDS")
    public ResponseEntity<Map<String, List<Map<String, Object>>>> getStoreDetails(@RequestParam("StoreID") int storeID) {
        try {
            Map<String, List<Map<String, Object>>> responseData = new HashMap<>();

            String query3 = "SELECT * FROM Store WHERE Code = ?";
            List<Map<String, Object>> storeDetails3 = TescoFDSJdbcTemplate.queryForList(query3, storeID);
            responseData.put("TESCO FDS Store", storeDetails3);

            String query4 = "SELECT * FROM StoreAppVersion WHERE Code = ?";
            List<Map<String, Object>> storeDetails4 = TescoFDSJdbcTemplate.queryForList(query4, storeID);
            responseData.put("TESCO FDS StoreAppVersion", storeDetails4);

            String query5 = "SELECT sc.* FROM StoreCategory sc " +
                    "INNER JOIN Store s ON sc.Store = s.Id " +
                    "WHERE s.Code = ?";
            ;
            List<Map<String, Object>> storeDetails5 = TescoFDSJdbcTemplate.queryForList(query5, storeID);
            responseData.put("Tesco FDS StoreCategory", storeDetails5);

            return ResponseEntity.ok().body(responseData);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }
}
