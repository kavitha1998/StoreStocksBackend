package com.FoodDonation.FoodDonation.InsertData;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.http.HttpStatus;

import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
public class FDInsertTescoFDS {

    @Autowired
    @Qualifier("TescoFDSJdbcTemplate")
    private JdbcTemplate TescoFDSJdbcTemplate;

    @PostMapping("/insertFDS")
    public ResponseEntity<Object> addTescoFDSInsert(@RequestBody Map<String, String> requestParams) {
        String Id = UUID.randomUUID().toString();
        String Retailer = requestParams.get("Retailer");
        String Name = requestParams.get("Name");
        String Code = requestParams.get("Code");
        String Live = requestParams.get("Live");
        String Address = requestParams.get("Address");
        String Postcode = requestParams.get("Postcode");
        Float GPSLat = Float.parseFloat(requestParams.get("GPSLat"));
        Float GPSLong = Float.parseFloat(requestParams.get("GPSLong"));
        String IPAddress = requestParams.get("IPAddress");
        String Options = requestParams.get("Options");
        String NextSchedule = requestParams.get("NextSchedule");
        String OpeningHours = requestParams.get("OpeningHours");
        String Comments = requestParams.get("Comments");
        String Updated = requestParams.get("Updated");
        String URL = requestParams.get("URL");
        String message = "";

        try {
            // Check if code exists in Store table
            int storeCount = TescoFDSJdbcTemplate.queryForObject(
                    "SELECT COUNT(*) FROM Store WHERE Code = ?", Integer.class, Code);
            int appVersionCount = TescoFDSJdbcTemplate.queryForObject(
                    "SELECT COUNT(*) FROM StoreAppVersion WHERE Code = ?", Integer.class, Code);

            if (storeCount == 0 && appVersionCount == 0) {
                // Insert into Store table if code does not exist in either table
                TescoFDSJdbcTemplate.update(
                        "INSERT INTO Store(Id, Retailer, Name, Code, Live, Address, Postcode, GPSLat, GPSLong, IPAddress, NextSchedule, Options, OpeningHours, Comments, Updated, URL) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                        Id, Retailer, Name, Code, Live, Address, Postcode, GPSLat, GPSLong, IPAddress, NextSchedule, Options, OpeningHours, Comments, Updated, URL);
                message = "Data inserted successfully into Store";

                // Insert into StoreAppVersion table
                TescoFDSJdbcTemplate.update(
                        "INSERT INTO StoreAppVersion(Id, Name, Code, IPAddress, AppVersion) VALUES (?, ?, ?, ?, ?)",
                        Id, Name, Code, IPAddress, 0);
                message += " and StoreAppVersion";
            } else if (storeCount == 0 && appVersionCount == 1) {
                // Insert only into Store table if code exists in StoreAppVersion but not in Store
                TescoFDSJdbcTemplate.update(
                        "INSERT INTO Store(Id, Retailer, Name, Code, Live, Address, Postcode, GPSLat, GPSLong, IPAddress, NextSchedule, Options, OpeningHours, Comments, Updated, URL) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                        Id, Retailer, Name, Code, Live, Address, Postcode, GPSLat, GPSLong, IPAddress, NextSchedule, Options, OpeningHours, Comments, Updated, URL);
                message = "Data inserted successfully into Store";
            } else if (storeCount == 1 && appVersionCount == 0) {
                // Insert only into StoreAppVersion table if code exists in Store but not in StoreAppVersion
                TescoFDSJdbcTemplate.update(
                        "INSERT INTO StoreAppVersion(Id, Name, Code, IPAddress, AppVersion) VALUES (?, ?, ?, ?, ?)",
                        Id, Name, Code, IPAddress, 0);
                message = "Data inserted successfully into StoreAppVersion";
            } else {
                // Data already exists in both tables
                message = "Data already exists in tables.";
                return ResponseEntity.status(HttpStatus.CONFLICT).body(message);
            }

            // Insert into StoreCategory table
            TescoFDSJdbcTemplate.update(
                    "INSERT INTO StoreCategory(Store, Category) SELECT a.Id, b.Id FROM Store a, Category b WHERE a.Code = ?",
                    Code);

            message += " and StoreCategory.";
            return ResponseEntity.ok().body(message);
        } catch (Exception e) {
            message = "Error: " + e.getMessage();
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(message);
        }
    }

    @GetMapping("/getTescoFDS")
    public ResponseEntity<List<Map<String, Object>>> getAllStores(@RequestParam String code) {
        try {
            List<Map<String, Object>> stores = TescoFDSJdbcTemplate.queryForList(
                    "SELECT s.*, sav.AppVersion FROM Store s " +
                            "INNER JOIN StoreAppVersion sav ON s.Code = sav.Code " +
                            "WHERE s.Code=?", code);
            return ResponseEntity.ok().body(stores);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }



}

