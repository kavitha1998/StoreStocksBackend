package com.viewnew.viewnew;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ViewnewApplicationTests {

	@Test
	void contextLoads() {
	}

}
