package com.store.stocks.config;

import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;

@EnableAutoConfiguration(exclude = { DataSourceAutoConfiguration.class, HibernateJpaAutoConfiguration.class })

@Configuration
public class ViewConfig {

    @Bean(name = "tescoDataSource")
    public DataSource tescoDataSource() {
        return DataSourceBuilder
                .create()
                .url("jdbc:sqlserver://127.0.0.1:1433;databaseName=Tesco_CAA;encrypt=false")
                .username("sa")
                .password("Soprasteria@12345")
                .driverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver")
                .build();
    }

    @Bean(name = "directDeliveriesDataSource")
    public DataSource directDeliveriesDataSource() {
        return DataSourceBuilder
                .create()
                .url("jdbc:sqlserver://127.0.0.1:1433;databaseName=db_DirectDeliveries;encrypt=false")
                .username("sa")
                .password("Soprasteria@12345")
                .driverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver")
                .build();
    }

    @Bean(name = "tescoJdbcTemplate")
    public JdbcTemplate tescoJdbcTemplate(@Qualifier("tescoDataSource") DataSource tescoDataSource) {
        return new JdbcTemplate(tescoDataSource);
    }

    @Bean(name = "directDeliveriesJdbcTemplate")
    public JdbcTemplate directDeliveriesJdbcTemplate(@Qualifier("directDeliveriesDataSource") DataSource directDeliveriesDataSource) {
        return new JdbcTemplate(directDeliveriesDataSource);
    }
}
