/*package com.store.stocks.InsertData;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.http.HttpStatus;

import java.util.Map;

@RestController
public class DirectDeliveries {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    @Qualifier("sqlServerJdbcTemplate")
    private JdbcTemplate sqlServerJdbcTemplate;

    @PostMapping("/tablesotrecountryinsert")
    public ResponseEntity<String> addStoreCountry(@RequestBody Map<String, String> requestParams) {
        String storeId = requestParams.get("StoreID");
        String countryId = requestParams.get("CountryID");
        String countryName = requestParams.get("CountryName");
        String isPilot = requestParams.get("IsPilot");
        String storeFormat = requestParams.get("StoreFormat");
        String countryCode = requestParams.get("CountryCode");
        String message = "";

        try {
            int storeCount = jdbcTemplate.queryForObject(
                    "SELECT COUNT(*) FROM tbl_Store WHERE StoreID = ?", Integer.class, storeId);
            int storeCountryCount = jdbcTemplate.queryForObject(
                    "SELECT COUNT(*) FROM tbl_Store_Country WHERE StoreID = ?", Integer.class, storeId);

            if (storeCount > 0) {
                if (storeCountryCount == 0) {
                    message = "StoreID already exists in tbl_Store. Data inserted successfully in tbl_Store_Country.";
                    jdbcTemplate.update(
                            "INSERT INTO tbl_Store_Country(StoreID, CountryID, CountryName, IsPilot, StoreFormat, CountryCode) VALUES (?, ?, ?, ?, ?, ?)",
                            storeId, countryId, countryName, isPilot, storeFormat, countryCode);
                } else {
                    message = "StoreID already exists in tbl_Store and tbl_Store_Country.";
                }
            } else {
                if (storeCountryCount > 0) {
                    message = "StoreID already exists in tbl_Store_Country. Data inserted successfully in tbl_Store.";
                    jdbcTemplate.update(
                            "INSERT INTO tbl_Store(StoreID) VALUES (?)", storeId);
                } else {
                    message = "Data inserted successfully into tbl_Store and tbl_Store_Country.";
                    jdbcTemplate.update(
                            "INSERT INTO tbl_Store(StoreID) VALUES (?)", storeId);
                    jdbcTemplate.update(
                            "INSERT INTO tbl_Store_Country(StoreID, CountryID, CountryName, IsPilot, StoreFormat, CountryCode) VALUES (?, ?, ?, ?, ?, ?)",
                            storeId, countryId, countryName, isPilot, storeFormat, countryCode);
                }
            }
            return ResponseEntity.ok().body(message);
        } catch (Exception e) {
            message = "Error: " + e.getMessage();
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(message);
        }
    }
}
*/