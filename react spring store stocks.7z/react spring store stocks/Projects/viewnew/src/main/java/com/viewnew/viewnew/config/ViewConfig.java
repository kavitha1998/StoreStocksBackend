package com.viewnew.viewnew.config;



import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.boot.jdbc.DataSourceBuilder;



@Configuration
public class ViewConfig {

    @Bean(name = "CountsDataSource")
    public DataSource CountsDataSource() {
        return DataSourceBuilder
                .create()
                .url("jdbc:sqlserver://127.0.0.1:1433;databaseName=Tesco_CAA;encrypt=false")
                .username("sa")
                .password("Soprasteria@12345")
                .driverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver")
                .build();
    }

    @Bean(name = "directDeliveriesDataSource")
    public DataSource directDeliveriesDataSource() {
        return DataSourceBuilder
                .create()
                .url("jdbc:sqlserver://127.0.0.1:1433;databaseName=db_DirectDeliveries;encrypt=false")
                .username("sa")
                .password("Soprasteria@12345")
                .driverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver")
                .build();
    }
    @Bean(name = "TescoFDSDataSource")
    public DataSource TescoFDSDataSource() {
        return DataSourceBuilder
                .create()
                .url("jdbc:sqlserver://127.0.0.1:1433;databaseName=TescoFDS;encrypt=false")
                .username("sa")
                .password("Soprasteria@12345")
                .driverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver")
                .build();
    }

    @Bean(name = "TescoFDSv2DataSource")
    public DataSource TescoFDSv2DataSource() {
        return DataSourceBuilder
                .create()
                .url("jdbc:sqlserver://127.0.0.1:1433;databaseName=TescoFDSv2;encrypt=false")
                .username("sa")
                .password("Soprasteria@12345")
                .driverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver")
                .build();
    }

    @Bean(name = "TescoFDSv2_PilotDataSource")
    public DataSource TescoFDSv2_PilotDataSource() {
        return DataSourceBuilder
                .create()
                .url("jdbc:sqlserver://127.0.0.1:1433;databaseName=TescoFDSv2_Pilot;encrypt=false")
                .username("sa")
                .password("Soprasteria@12345")
                .driverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver")
                .build();
    }

   @Bean(name = "RFSDataSource")
   public DataSource RFSDataSource() {
       return DataSourceBuilder
               .create()
               .url("jdbc:sqlserver://127.0.0.1:1433;databaseName=RFS_Prod;encrypt=false")
               .username("sa")
               .password("Soprasteria@12345")
               .driverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver")
               .build();
   }
    @Bean(name = "CountsJdbcTemplate")
    public JdbcTemplate CountsJdbcTemplate(@Qualifier("CountsDataSource") DataSource CountsDataSource) {
        return new JdbcTemplate(CountsDataSource);
    }

    @Bean(name = "directDeliveriesJdbcTemplate")
    public JdbcTemplate directDeliveriesJdbcTemplate(@Qualifier("directDeliveriesDataSource") DataSource directDeliveriesDataSource) {
        return new JdbcTemplate(directDeliveriesDataSource);
    }

    @Bean(name = "TescoFDSJdbcTemplate")
    public JdbcTemplate TescoFDSJdbcTemplate(@Qualifier("TescoFDSDataSource") DataSource TescoFDSDataSource) {
        return new JdbcTemplate(TescoFDSDataSource);
    }
    @Bean(name = "TescoFDSv2JdbcTemplate")
    public JdbcTemplate TescoFDSv2JdbcTemplate(@Qualifier("TescoFDSv2DataSource") DataSource TescoFDSv2DataSource) {
        return new JdbcTemplate(TescoFDSv2DataSource);
    }


    @Bean(name = "TescoFDSv2_PilotJdbcTemplate")
    public JdbcTemplate TescoFDSv2_PilotJdbcTemplate(@Qualifier("TescoFDSv2_PilotDataSource") DataSource TescoFDSv2_PilotDataSource) {
        return new JdbcTemplate(TescoFDSv2_PilotDataSource);
    }
    @Bean(name = "RFSJdbcTemplate")
    public JdbcTemplate RFSJdbcTemplate(@Qualifier("RFSDataSource") DataSource RFSDataSource) {
        return new JdbcTemplate(RFSDataSource);
    }


    }

